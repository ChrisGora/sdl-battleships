#include "state.h"
#include <stdbool.h>

void showMessage(bool useDisplay, display *d, char* title, char* message, bool printTitle);
